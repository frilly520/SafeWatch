---
name: PWA cache in Replit previews
description: Service-worker behavior that can make Replit's Vite development preview show stale app assets.
---

Register the app's service worker only in production builds. In Replit's Vite preview, a persistent worker can serve cached HTML or modules across workflow restarts, making new UI changes appear missing. Use network-first fetches with cached fallbacks for production offline support, and scope cache cleanup to this app's own cache prefix.

**Why:** A stale worker hid a completed dark-theme update in the proxied preview until the cache strategy and dev registration were corrected.

**How to apply:** For future PWA artifacts, disable or unregister service workers in development and avoid cache-first behavior for development modules.
