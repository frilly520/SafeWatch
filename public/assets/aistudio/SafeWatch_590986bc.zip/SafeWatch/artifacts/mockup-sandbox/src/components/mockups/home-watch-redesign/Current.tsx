import './_group.css';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle, Bell, Camera, Check, CircleHelp, Download, Eye, Film,
  HardDrive, House, Info, LoaderCircle, LockKeyhole, MonitorOff, Play, Radio,
  RefreshCw, ShieldCheck, Siren, Smartphone, StopCircle,
  Trash2, Video, Volume2, VolumeX, X,
} from 'lucide-react';

type Clip = { id: number; createdAt: number; blob: Blob; type: string };
type ViewMode = 'camera' | 'viewer';
const DB_NAME = 'home-watch-local';
const DB_STORE = 'clips';

function openClipDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB is not available in this browser.'));
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open local clip storage.'));
  });
}

async function readClips(): Promise<Clip[]> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction(DB_STORE, 'readonly').objectStore(DB_STORE).getAll();
    request.onsuccess = () => { db.close(); resolve((request.result as Clip[]).sort((a, b) => b.createdAt - a.createdAt)); };
    request.onerror = () => { db.close(); reject(request.error || new Error('Could not read saved clips.')); };
  });
}

async function saveClip(clip: Clip): Promise<void> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put(clip);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Storage is full or unavailable.')); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error('The clip could not be saved.')); };
  });
}

async function removeClip(id: number): Promise<void> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Could not remove clip.')); };
  });
}

function formatTime(timestamp: number) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(timestamp);
}

function App() {
  const [mode, setMode] = useState<ViewMode>('camera');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [running, setRunning] = useState(false);
  const [starting, setStarting] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState('');
  const [sensitivity, setSensitivity] = useState(58);
  const [motionEnabled, setMotionEnabled] = useState(true);
  const [dim, setDim] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [sirenOn, setSirenOn] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [error, setError] = useState('');
  const [storageError, setStorageError] = useState('');
  const [clips, setClips] = useState<Clip[]>([]);
  const [activeClip, setActiveClip] = useState<number | null>(null);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);
  const lastPixelsRef = useRef<Uint8ClampedArray | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordChunksRef = useRef<BlobPart[]>([]);
  const recordingRef = useRef(false);
  const streamRef = useRef<MediaStream | null>(null);
  const alertTimerRef = useRef<number | undefined>(undefined);
  const sirenAudioRef = useRef<AudioContext | null>(null);
  const clipUrls = useMemo(() => new Map(clips.map(clip => [clip.id, URL.createObjectURL(clip.blob)])), [clips]);

  useEffect(() => () => { clipUrls.forEach(url => URL.revokeObjectURL(url)); }, [clipUrls]);

  const refreshClips = useCallback(async () => {
    try { setClips(await readClips()); setStorageError(''); }
    catch (e) { setStorageError(e instanceof Error ? e.message : 'Local clip storage is unavailable.'); }
  }, []);

  useEffect(() => {
    void refreshClips();
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener('beforeinstallprompt', onInstall);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, [refreshClips]);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [stream, mode]);

  useEffect(() => {
    if (!running || !('wakeLock' in navigator)) return;
    let disposed = false;
    const requestWakeLock = async () => {
      if (document.visibilityState !== 'visible' || wakeLockRef.current) return;
      try {
        const lock = await navigator.wakeLock.request('screen');
        if (disposed) {
          await lock.release();
          return;
        }
        wakeLockRef.current = lock;
        lock.addEventListener('release', () => {
          if (wakeLockRef.current === lock) wakeLockRef.current = null;
        }, { once: true });
      } catch { /* Wake Lock is optional and varies by browser. */ }
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') void requestWakeLock();
    };
    void requestWakeLock();
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      disposed = true;
      document.removeEventListener('visibilitychange', onVisibilityChange);
      const lock = wakeLockRef.current;
      wakeLockRef.current = null;
      if (lock && !lock.released) void lock.release();
    };
  }, [running]);

  const playWarning = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = sirenAudioRef.current?.state === 'closed'
        ? new AudioContextClass()
        : sirenAudioRef.current ?? new AudioContextClass();
      sirenAudioRef.current = ctx;
      void ctx.resume().then(() => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(740, ctx.currentTime);
        osc.frequency.setValueAtTime(520, ctx.currentTime + 0.18);
        osc.frequency.setValueAtTime(740, ctx.currentTime + 0.36);
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.13, ctx.currentTime + 0.025);
        gain.gain.setValueAtTime(0.13, ctx.currentTime + 0.5);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.65);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.68);
        osc.onended = () => { osc.disconnect(); gain.disconnect(); };
      }).catch(() => { /* Browser audio can be blocked independently. */ });
    } catch { /* Sound is optional; the visual alert remains available. */ }
  }, [soundEnabled]);

  const showAlert = useCallback((text: string) => {
    setAlertText(text);
    window.clearTimeout(alertTimerRef.current);
    alertTimerRef.current = window.setTimeout(() => setAlertText(''), 5200);
    playWarning();
  }, [playWarning]);

  const saveRecording = useCallback(async (blob: Blob) => {
    if (!blob.size) return;
    try {
      const clip: Clip = { id: Date.now(), createdAt: Date.now(), blob, type: blob.type || 'video/webm' };
      await saveClip(clip);
      await refreshClips();
      setStorageError('');
    } catch (e) {
      setStorageError(e instanceof Error ? `Recording couldn't be saved: ${e.message}` : 'Recording could not be saved. Check available device storage.');
    }
  }, [refreshClips]);

  const beginRecording = useCallback(() => {
    const current = streamRef.current;
    if (!current || recordingRef.current || typeof MediaRecorder === 'undefined') return;
    const supported = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4;codecs=h264,aac', 'video/mp4']
      .find(type => MediaRecorder.isTypeSupported(type));
    if (!supported) { setError('This browser does not support a compatible local video recording format.'); return; }
    try {
      const recorder = new MediaRecorder(current, { mimeType: supported });
      recordChunksRef.current = [];
      recordingRef.current = true;
      recorderRef.current = recorder;
      recorder.ondataavailable = event => { if (event.data.size) recordChunksRef.current.push(event.data); };
      recorder.onerror = () => { setError('The browser could not record this event.'); recordingRef.current = false; };
      recorder.onstop = () => {
        const blob = new Blob(recordChunksRef.current, { type: supported });
        recordChunksRef.current = [];
        recordingRef.current = false;
        void saveRecording(blob);
      };
      recorder.start(500);
      window.setTimeout(() => {
        if (recorder.state !== 'inactive') recorder.stop();
      }, 10_000);
    } catch (e) {
      recordingRef.current = false;
      setError(e instanceof Error ? `Recording unavailable: ${e.message}` : 'Could not start local recording.');
    }
  }, [saveRecording]);

  const stopCamera = useCallback(() => {
    cancelAnimationFrame(frameRef.current);
    frameRef.current = 0;
    const current = streamRef.current;
    current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    setStream(null);
    setRunning(false);
    setDim(false);
    lastPixelsRef.current = null;
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try { recorder.stop(); } catch { /* Already stopped. */ }
    }
  }, []);

  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      setDevices(all.filter(device => device.kind === 'videoinput'));
    } catch { setDevices([]); }
  }, []);

  const startCamera = useCallback(async () => {
    setError('');
    setStarting(true);
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access requires a secure context (HTTPS or localhost) and a browser that supports camera capture.');
      if (soundEnabled) {
        try {
          const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
          if (AudioContextClass) {
            const ctx = sirenAudioRef.current?.state === 'closed'
              ? new AudioContextClass()
              : sirenAudioRef.current ?? new AudioContextClass();
            sirenAudioRef.current = ctx;
            void ctx.resume().catch(() => { /* Visual alerts remain available if audio is blocked. */ });
          }
        } catch { /* Audio support is optional. */ }
      }
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: deviceId ? { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { facingMode: { ideal: cameraFacing }, width: { ideal: 1280 }, height: { ideal: 720 } },
      };
      const media = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = media;
      setStream(media);
      setRunning(true);
      const activeDeviceId = media.getVideoTracks()[0]?.getSettings().deviceId;
      if (activeDeviceId) setDeviceId(activeDeviceId);
      media.getVideoTracks()[0]?.addEventListener('ended', () => {
        stopCamera();
        setError('Camera capture ended. Your browser or device may have paused the camera.');
      }, { once: true });
      await refreshDevices();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Camera could not start. Check browser permission and try again.');
      stopCamera();
    } finally { setStarting(false); }
  }, [cameraFacing, deviceId, refreshDevices, soundEnabled, stopCamera]);

  useEffect(() => {
    if (!running || !motionEnabled || !stream) {
      cancelAnimationFrame(frameRef.current);
      frameRef.current = 0;
      lastPixelsRef.current = null;
      return;
    }
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return;
    canvas.width = 64;
    canvas.height = 36;
    let lastSample = 0;
    let lastTrigger = 0;
    const sample = (time: number) => {
      frameRef.current = requestAnimationFrame(sample);
      if (time - lastSample < 180 || video.readyState < 2 || video.videoWidth === 0) return;
      lastSample = time;
      try {
        context.drawImage(video, 0, 0, 64, 36);
        const current = context.getImageData(0, 0, 64, 36).data;
        const previous = lastPixelsRef.current;
        lastPixelsRef.current = new Uint8ClampedArray(current);
        if (!previous) return;
        let changed = 0;
        let totalDiff = 0;
        for (let i = 0; i < current.length; i += 4) {
          const lum = (current[i] * .299 + current[i + 1] * .587 + current[i + 2] * .114);
          const oldLum = (previous[i] * .299 + previous[i + 1] * .587 + previous[i + 2] * .114);
          const diff = Math.abs(lum - oldLum);
          if (diff > 26) { changed++; totalDiff += diff; }
        }
        // Reject tiny flicker/noise; sensitivity adjusts the percentage of frame that must change.
        const changedRatio = changed / (64 * 36);
        const threshold = .105 - sensitivity * .00088;
        if (changedRatio > threshold && totalDiff / Math.max(changed, 1) > 34 && time - lastTrigger > 12_000) {
          lastTrigger = time;
          showAlert('Movement detected');
          beginRecording();
        }
      } catch {
        setError('Motion sampling is unavailable for this camera stream. Try another browser or camera.');
      }
    };
    frameRef.current = requestAnimationFrame(sample);
    return () => cancelAnimationFrame(frameRef.current);
  }, [beginRecording, motionEnabled, running, sensitivity, showAlert, stream]);

  useEffect(() => () => {
    cancelAnimationFrame(frameRef.current);
    streamRef.current?.getTracks().forEach(track => track.stop());
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') { try { recorder.stop(); } catch { /* unmount */ } }
    if (sirenAudioRef.current && sirenAudioRef.current.state !== 'closed') void sirenAudioRef.current.close();
    window.clearTimeout(alertTimerRef.current);
  }, []);

  const playSiren = useCallback(() => {
    const next = !sirenOn;
    setSirenOn(next);
    if (next) {
      setAlertText('Siren simulation active');
      window.clearTimeout(alertTimerRef.current);
      alertTimerRef.current = window.setTimeout(() => { setSirenOn(false); setAlertText(''); }, 6500);
      playWarning();
    } else {
      window.clearTimeout(alertTimerRef.current);
      setAlertText('');
    }
  }, [playWarning, sirenOn]);

  const deleteClip = async (id: number) => {
    try {
      await removeClip(id);
      setClips(items => items.filter(item => item.id !== id));
      if (activeClip === id) setActiveClip(null);
    } catch (e) { setStorageError(e instanceof Error ? e.message : 'Could not delete clip.'); }
  };

  const downloadClip = (clip: Clip) => {
    const url = URL.createObjectURL(clip.blob);
    const link = document.createElement('a');
    link.href = url;
    const extension = clip.type.includes('mp4') ? 'mp4' : 'webm';
    link.download = `home-watch-${new Date(clip.createdAt).toISOString().replace(/[:.]/g, '-')}.${extension}`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1200);
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const result = await installPrompt.userChoice;
    if (result.outcome === 'accepted') setInstalled(true);
    setInstallPrompt(null);
  };

  return (
    <main className="app-shell">
      <header className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-5 md:px-9">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#1e5147] text-[#f8f3e8] shadow-sm"><House size={22} strokeWidth={1.8} /></div>
          <div><div className="brand-display text-[19px] font-extrabold tracking-[-.04em]">Home Watch</div><div className="mono text-[10px] uppercase tracking-[.17em] text-[#74837a]">Your home, in view</div></div>
        </div>
        <div className="flex items-center gap-2">
          {installPrompt && <button onClick={installApp} className="hidden items-center gap-2 rounded-xl border border-[#d8d5ca] bg-[#fbfaf5] px-3 py-2 text-xs font-semibold text-[#35554b] hover:bg-white sm:flex" data-testid="button-install"><Download size={15} /> Install app</button>}
          {installed && <span className="hidden items-center gap-1 text-xs text-[#486d5f] sm:flex"><Check size={15} /> Installed</span>}
          <span className="flex items-center gap-2 rounded-full border border-[#d9e2d8] bg-[#e9f0e7] px-3 py-2 text-[11px] font-semibold text-[#3b6956]"><LockKeyhole size={13} /> LOCAL ONLY</span>
        </div>
      </header>

      <section className="mx-auto max-w-[1440px] px-5 pb-10 md:px-9">
        <div className="mb-7 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div className="entrance">
            <p className="mono mb-2 text-[11px] uppercase tracking-[.19em] text-[#78877e]">Personal camera workspace</p>
            <h1 className="brand-display text-3xl font-extrabold tracking-[-.055em] text-[#1f3731] md:text-[42px]">A little more peace of mind.</h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-[#66756d]">Turn a spare phone into a motion-aware camera. Your recordings stay in this browser, on this device.</p>
          </div>
          <div className="flex rounded-2xl border border-[#ddd9ce] bg-[#eae7dd] p-1.5" role="tablist" aria-label="Workspace mode">
            <button onClick={() => setMode('camera')} role="tab" aria-selected={mode === 'camera'} className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${mode === 'camera' ? 'bg-[#fbfaf5] text-[#25483e] shadow-sm' : 'text-[#758078] hover:text-[#25483e]'}`} data-testid="tab-camera"><Camera size={16} /> Camera mode</button>
            <button onClick={() => { if (running) stopCamera(); setMode('viewer'); }} role="tab" aria-selected={mode === 'viewer'} className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${mode === 'viewer' ? 'bg-[#fbfaf5] text-[#25483e] shadow-sm' : 'text-[#758078] hover:text-[#25483e]'}`} data-testid="tab-viewer"><Eye size={16} /> Viewer mode</button>
          </div>
        </div>

        {(alertText || error || storageError) && <div className={`mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border px-4 py-3 ${alertText ? 'border-[#e7c7b6] bg-[#fff0e8] text-[#8b4935]' : 'border-[#e6c6b7] bg-[#fff1eb] text-[#824632]'}`} role="status" aria-live="assertive">
          <div className="flex items-start gap-2.5">{alertText ? <Bell size={18} className="mt-0.5 shrink-0" /> : <AlertTriangle size={18} className="mt-0.5 shrink-0" />}<span className="text-sm font-semibold">{alertText || error || storageError}</span></div>
          {alertText && <button onClick={() => { setAlertText(''); setSirenOn(false); }} aria-label="Dismiss alert" className="rounded-lg p-1 hover:bg-[#f4ded2]"><X size={17} /></button>}
        </div>}

        <div className="dashboard-grid">
          <section className="min-w-0 overflow-hidden rounded-[26px] border border-[#ddd9ce] bg-[#fbfaf5] shadow-[0_8px_28px_rgba(32,54,46,.045)]">
            <div className="flex items-center justify-between gap-3 px-5 py-4 md:px-6">
              <div className="flex items-center gap-2.5"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#e8eee6] text-[#426857]"><Video size={18} /></div><div><h2 className="brand-display text-base font-bold tracking-[-.02em]">{mode === 'camera' ? 'Camera preview' : 'Live view'}</h2><p className="text-[11px] text-[#829087]">{mode === 'camera' ? 'This device camera' : 'Remote camera connection'}</p></div></div>
              {mode === 'camera' && <span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.12em] ${running ? 'bg-[#eaf3e8] text-[#477353]' : 'bg-[#eeece5] text-[#83887f]'}`}><span className={`h-1.5 w-1.5 rounded-full ${running ? 'status-live bg-[#61a56c]' : 'bg-[#9ea39b]'}`} />{running ? 'Monitoring' : 'Standby'}</span>}
              {mode === 'viewer' && <span className="rounded-full bg-[#f3eadc] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.1em] text-[#986d34]">Not paired</span>}
            </div>
            <div className={`camera-stage ${alertText ? 'alert-flash' : ''}`}>
              {mode === 'camera' && stream ? <video ref={videoRef} autoPlay playsInline muted aria-label="Active camera preview" data-testid="camera-preview" /> : null}
              <div className="camera-grid" />
              <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
              {mode === 'camera' && !stream && <div className="absolute inset-0 z-[1] flex flex-col items-center justify-center px-6 text-center text-[#f6f0e2]">
                <div className="mb-4 grid h-[68px] w-[68px] place-items-center rounded-[22px] border border-white/15 bg-white/[.08]"><Camera size={28} strokeWidth={1.5} /></div>
                <p className="brand-display text-xl font-bold tracking-[-.03em]">Ready when you are</p>
                <p className="mt-2 max-w-sm text-sm leading-6 text-[#d0d5ca]">Start monitoring to preview this device's camera. Nothing is uploaded or streamed elsewhere.</p>
                <span className="mono mt-5 rounded-full border border-white/15 px-3 py-1.5 text-[10px] uppercase tracking-[.15em] text-[#c3cec4]">Camera feed appears here</span>
              </div>}
              {mode === 'viewer' && <div className="absolute inset-0 z-[1] flex flex-col items-center justify-center px-6 text-center text-[#f6f0e2]">
                <div className="mb-4 grid h-[68px] w-[68px] place-items-center rounded-[22px] border border-white/15 bg-white/[.08]"><Radio size={27} strokeWidth={1.5} /></div>
                <p className="brand-display text-xl font-bold tracking-[-.03em]">Peer-to-peer pairing isn’t active yet</p>
                <p className="mt-2 max-w-md text-sm leading-6 text-[#d0d5ca]">This is not a live feed. Remote pairing is a future capability; for now, review clips stored locally on this device.</p>
                <span className="mono mt-5 rounded-full border border-white/15 px-3 py-1.5 text-[10px] uppercase tracking-[.13em] text-[#c3cec4]">No connection · No remote video</span>
              </div>}
              {mode === 'camera' && running && <div className="absolute bottom-4 left-4 z-[2] flex items-center gap-2 rounded-lg bg-[#172823]/75 px-3 py-2 text-xs text-white backdrop-blur-sm"><span className="status-live h-2 w-2 rounded-full bg-[#80c77c]" /> Camera active on this device</div>}
            </div>
            {mode === 'camera' ? <div className="space-y-5 p-5 md:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex gap-2">
                  {!running ? <button onClick={startCamera} disabled={starting} className="flex items-center gap-2 rounded-xl bg-[#245448] px-4 py-3 text-sm font-bold text-[#fbf8ed] shadow-sm transition hover:bg-[#1d493e] disabled:opacity-65" data-testid="button-start-camera">{starting ? <LoaderCircle size={17} className="animate-spin" /> : <Play size={16} fill="currentColor" />}{starting ? 'Requesting camera…' : 'Start monitoring'}</button> : <button onClick={stopCamera} className="flex items-center gap-2 rounded-xl bg-[#f7e7e0] px-4 py-3 text-sm font-bold text-[#914d3c] hover:bg-[#f2d9ce]" data-testid="button-stop-camera"><StopCircle size={17} /> Stop monitoring</button>}
                </div>
                <label className="flex items-center gap-2 text-xs font-medium text-[#66766d]"><span>Camera</span><select value={deviceId || cameraFacing} onChange={e => {
                  const value = e.target.value;
                  if (value === 'user' || value === 'environment') { setCameraFacing(value); setDeviceId(''); }
                  else { setDeviceId(value); }
                  if (running) stopCamera();
                }} className="max-w-[190px] rounded-lg border border-[#dedace] bg-[#f7f5ee] px-2.5 py-2 text-xs text-[#345348] outline-none focus:ring-2 focus:ring-[#9db7a4]" aria-label="Choose camera" data-testid="select-camera">
                  <option value="environment">Back camera</option>
                  <option value="user">Front camera</option>
                  {devices.map((device, index) => <option key={device.deviceId} value={device.deviceId}>{device.label || `Camera ${index + 1}`}</option>)}
                </select></label>
              </div>
              {devices.length === 0 && <p className="-mt-3 text-[11px] text-[#8b958c]">Front / back choice is used until camera permission reveals available devices.</p>}
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-[#e3dfd3] bg-[#f7f5ee] p-4">
                  <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2 text-sm font-semibold text-[#334b42]"><ShieldCheck size={17} /> Motion detection</div><button role="switch" aria-checked={motionEnabled} onClick={() => setMotionEnabled(v => !v)} className={`relative h-6 w-11 rounded-full transition ${motionEnabled ? 'bg-[#487960]' : 'bg-[#c4c8bf]'}`} aria-label="Toggle motion detection" data-testid="toggle-motion"><span className={`absolute top-[3px] h-[18px] w-[18px] rounded-full bg-white shadow-sm transition-transform ${motionEnabled ? 'translate-x-[21px]' : 'translate-x-[3px]'}`} /></button></div>
                  <label className="block text-xs text-[#748078]">Sensitivity <span className="float-right font-semibold text-[#486558]">{sensitivity}%</span><input type="range" min="10" max="90" value={sensitivity} onChange={e => setSensitivity(Number(e.target.value))} className="mt-3 w-full accent-[#46755f]" aria-label="Motion sensitivity" data-testid="slider-sensitivity" /></label>
                  <p className="mt-2 text-[10px] leading-4 text-[#8a948b]">Pixel changes are sampled locally. Very small changes are filtered as noise.</p>
                </div>
                <div className="rounded-2xl border border-[#e3dfd3] bg-[#f7f5ee] p-4">
                  <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2 text-sm font-semibold text-[#334b42]"><MonitorOff size={17} /> Dim screen</div><button role="switch" aria-checked={dim} disabled={!running} onClick={() => setDim(v => !v)} className={`relative h-6 w-11 rounded-full transition disabled:opacity-40 ${dim ? 'bg-[#487960]' : 'bg-[#c4c8bf]'}`} aria-label="Toggle dim screen" data-testid="toggle-dim"><span className={`absolute top-[3px] h-[18px] w-[18px] rounded-full bg-white shadow-sm transition-transform ${dim ? 'translate-x-[21px]' : 'translate-x-[3px]'}`} /></button></div>
                  <p className="text-xs leading-5 text-[#748078]">Reduces screen brightness while monitoring. Tap the dark preview to reveal controls.</p>
                  <button onClick={() => setSoundEnabled(v => !v)} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#557464] hover:text-[#234c3c]" data-testid="button-toggle-sound">{soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}{soundEnabled ? 'Warning sound on' : 'Warning sound off'}</button>
                </div>
              </div>
            </div> : <div className="flex flex-wrap items-center justify-between gap-3 p-5 md:p-6">
              <div className="flex items-start gap-3"><div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#f2eadb] text-[#99703a]"><Info size={17} /></div><div><p className="text-sm font-semibold text-[#364b41]">Local clips only</p><p className="mt-1 max-w-lg text-xs leading-5 text-[#79847a]">Recordings do not sync across devices. A future pairing feature is not currently connected.</p></div></div>
              <button onClick={playSiren} className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${sirenOn ? 'bg-[#a84f3d] text-white' : 'border border-[#e1cfc0] bg-[#fbf2e8] text-[#8d5939] hover:bg-[#f7eadb]'}`} data-testid="button-siren"><Siren size={17} />{sirenOn ? 'Stop siren' : 'Simulate siren'}</button>
            </div>}
          </section>

          <aside className="flex min-w-0 flex-col gap-5">
            <section className="rounded-[26px] border border-[#ddd9ce] bg-[#fbfaf5] p-5 shadow-[0_8px_28px_rgba(32,54,46,.035)] md:p-6">
              <div className="mb-4 flex items-center justify-between">
                <div><p className="mono text-[10px] uppercase tracking-[.16em] text-[#879188]">Event library</p><h2 className="brand-display mt-1 text-lg font-bold tracking-[-.03em]">Recent recordings</h2></div>
                <span className="mono rounded-full bg-[#e9eee6] px-2.5 py-1 text-xs text-[#4d6e5b]">{clips.length.toString().padStart(2, '0')}</span>
              </div>
              {storageError && <div className="mb-4 rounded-xl border border-[#e6c6b7] bg-[#fff1eb] px-3 py-2 text-xs leading-5 text-[#824632]" role="alert">{storageError}</div>}
              {clips.length === 0 ? <div className="rounded-2xl border border-dashed border-[#d9d8cc] bg-[#f8f6ef] px-5 py-8 text-center">
                <div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-[#e8eee6] text-[#65816d]"><Film size={20} /></div>
                <p className="text-sm font-semibold text-[#42584c]">No events saved yet</p>
                <p className="mx-auto mt-1.5 max-w-[225px] text-xs leading-5 text-[#829087]">When motion is detected, a 10-second clip will be stored in this browser.</p>
                <button onClick={refreshClips} className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-[#567463] hover:text-[#284c3b]" data-testid="button-refresh-clips"><RefreshCw size={13} /> Refresh library</button>
              </div> : <div className="space-y-3">
                {clips.map(clip => {
                  const url = clipUrls.get(clip.id) || '';
                  return <article key={clip.id} className="overflow-hidden rounded-2xl border border-[#e3dfd3] bg-[#f8f6ef]" data-testid={`recording-${clip.id}`}>
                    {activeClip === clip.id ? <video controls autoPlay src={url} className="aspect-video w-full bg-[#1c302b]" onEnded={() => setActiveClip(null)} aria-label={`Recording from ${formatTime(clip.createdAt)}`} /> : <div className="clip-thumb relative flex aspect-[2.25/1] items-center justify-center"><span className="absolute left-3 top-3 rounded-md bg-[#13241e]/70 px-2 py-1 text-[9px] font-bold uppercase tracking-[.13em] text-white">Motion event</span><button onClick={() => setActiveClip(clip.id)} className="grid h-10 w-10 place-items-center rounded-full border border-white/40 bg-[#f8f3e7]/90 text-[#234b3e] shadow-lg hover:scale-105" aria-label={`Play recording from ${formatTime(clip.createdAt)}`} data-testid={`button-play-${clip.id}`}><Play size={17} fill="currentColor" /></button></div>}
                    <div className="flex items-center justify-between gap-2 px-3.5 py-3">
                      <div className="min-w-0"><p className="truncate text-xs font-semibold text-[#40564a]">{formatTime(clip.createdAt)}</p><p className="mono mt-1 text-[9px] uppercase tracking-[.12em] text-[#929990]">10 sec · {clip.type.split(';')[0]}</p></div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => downloadClip(clip)} className="rounded-lg p-2 text-[#65806f] hover:bg-[#e8eee6] hover:text-[#315742]" aria-label="Download recording" title="Download" data-testid={`button-download-${clip.id}`}><Download size={16} /></button>
                        <button onClick={() => void deleteClip(clip.id)} className="rounded-lg p-2 text-[#9a8177] hover:bg-[#f2e4dc] hover:text-[#9b4b38]" aria-label="Delete recording" title="Delete" data-testid={`button-delete-${clip.id}`}><Trash2 size={15} /></button>
                      </div>
                    </div>
                  </article>;
                })}
              </div>}
              <div className="mt-4 flex items-center gap-2 border-t border-[#e7e3d9] pt-4 text-[11px] leading-4 text-[#879188]"><HardDrive size={14} className="shrink-0" />Stored in this browser only. Clearing site data removes recordings.</div>
            </section>
            <section className="rounded-[26px] bg-[#e7ece4] p-5 md:p-6">
              <div className="mb-3 flex items-center gap-2 text-[#466555]"><CircleHelp size={17} /><h2 className="text-sm font-bold">A note about camera use</h2></div>
              <p className="text-xs leading-[1.7] text-[#68796f]">Camera capture needs a secure context (HTTPS or localhost) and your permission. Mobile browsers may pause or stop capture when this page is backgrounded; keep Home Watch open and the screen awake for best results.</p>
              <div className="mt-4 flex items-center gap-2 border-t border-[#d5ded3] pt-3 text-[10px] font-medium text-[#718477]"><Smartphone size={13} /> No cloud. No account. No server storage.</div>
            </section>
            {installPrompt && <button onClick={installApp} className="flex items-center justify-center gap-2 rounded-xl border border-[#ddd9ce] bg-[#fbfaf5] px-4 py-3 text-sm font-semibold text-[#3e6150] sm:hidden"><Download size={16} /> Install Home Watch</button>}
            {installed && <div className="flex items-center gap-2 px-2 text-xs text-[#527361]"><Check size={15} /> Home Watch is installed on this device</div>}
          </aside>
        </div>
        <footer className="mt-7 flex flex-wrap items-center justify-between gap-2 border-t border-[#e1ddd2] pt-4 text-[10px] text-[#89938a]"><span>Home Watch · Browser-only personal safety tool</span><span className="mono">LOCAL BY DESIGN</span></footer>
      </section>
      {mode === 'camera' && dim && running && <button onClick={() => setDim(false)} className="dim-layer fixed inset-0 z-50 flex flex-col items-center justify-center gap-3 text-[#d7dfd6]" aria-label="Reveal camera controls" data-testid="button-reveal-controls"><Eye size={20} /><span className="text-xs">Tap anywhere to reveal controls</span></button>}
    </main>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default App;
