import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle, Bell, Camera, Check, CircleHelp, Download, Eye, Film,
  HardDrive, Heart, Info, LoaderCircle, LockKeyhole, MonitorOff, Play, Radio,
  RefreshCw, ShieldCheck, Siren, Smartphone, StopCircle, Terminal,
  Trash2, Video, Volume2, X,
} from 'lucide-react';

type Clip = { id: number; createdAt: number; blob: Blob; type: string };
type ViewMode = 'camera' | 'viewer';
const DB_NAME = 'home-watch-local';
const DB_STORE = 'clips';

function openClipDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB is not available in this browser.'));
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open local clip storage.'));
  });
}

async function readClips(): Promise<Clip[]> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction(DB_STORE, 'readonly').objectStore(DB_STORE).getAll();
    request.onsuccess = () => { db.close(); resolve((request.result as Clip[]).sort((a, b) => b.createdAt - a.createdAt)); };
    request.onerror = () => { db.close(); reject(request.error || new Error('Could not read saved clips.')); };
  });
}

async function saveClip(clip: Clip): Promise<void> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put(clip);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Storage is full or unavailable.')); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error('The clip could not be saved.')); };
  });
}

async function removeClip(id: number): Promise<void> {
  const db = await openClipDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('Could not remove clip.')); };
  });
}

function formatTime(timestamp: number) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(timestamp);
}

function App() {
  const [mode, setMode] = useState<ViewMode>('camera');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [running, setRunning] = useState(false);
  const [starting, setStarting] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState('');
  const [sensitivity, setSensitivity] = useState(58);
  const [motionEnabled, setMotionEnabled] = useState(true);
  const [dim, setDim] = useState(false);
  const [audioTripwire, setAudioTripwire] = useState(false);
  const [audioPayload, setAudioPayload] = useState<'tone' | 'chime' | 'siren'>('tone');
  const [recording, setRecording] = useState(false);
  const [sirenOn, setSirenOn] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [error, setError] = useState('');
  const [storageError, setStorageError] = useState('');
  const [clips, setClips] = useState<Clip[]>([]);
  const [activeClip, setActiveClip] = useState<number | null>(null);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);
  const lastPixelsRef = useRef<Uint8ClampedArray | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordChunksRef = useRef<BlobPart[]>([]);
  const recordingRef = useRef(false);
  const streamRef = useRef<MediaStream | null>(null);
  const alertTimerRef = useRef<number | undefined>(undefined);
  const sirenAudioRef = useRef<AudioContext | null>(null);
  const clipUrls = useMemo(() => new Map(clips.map(clip => [clip.id, URL.createObjectURL(clip.blob)])), [clips]);

  useEffect(() => () => { clipUrls.forEach(url => URL.revokeObjectURL(url)); }, [clipUrls]);

  const refreshClips = useCallback(async () => {
    try { setClips(await readClips()); setStorageError(''); }
    catch (e) { setStorageError(e instanceof Error ? e.message : 'Local clip storage is unavailable.'); }
  }, []);

  useEffect(() => {
    void refreshClips();
    if ('serviceWorker' in navigator) {
      if (import.meta.env.DEV) {
        void navigator.serviceWorker.getRegistrations().then(async registrations => {
          if (!registrations.length) return;
          await Promise.all(registrations.map(registration => registration.unregister()));
          if (navigator.serviceWorker.controller) window.location.reload();
        });
      } else {
        void navigator.serviceWorker.register('/service-worker.js').catch(() => undefined);
      }
    }
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener('beforeinstallprompt', onInstall);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, [refreshClips]);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [stream, mode]);

  useEffect(() => {
    if (!running || !('wakeLock' in navigator)) return;
    let disposed = false;
    const requestWakeLock = async () => {
      if (document.visibilityState !== 'visible' || wakeLockRef.current) return;
      try {
        const lock = await navigator.wakeLock.request('screen');
        if (disposed) {
          await lock.release();
          return;
        }
        wakeLockRef.current = lock;
        lock.addEventListener('release', () => {
          if (wakeLockRef.current === lock) wakeLockRef.current = null;
        }, { once: true });
      } catch { /* Wake Lock is optional and varies by browser. */ }
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') void requestWakeLock();
    };
    void requestWakeLock();
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      disposed = true;
      document.removeEventListener('visibilitychange', onVisibilityChange);
      const lock = wakeLockRef.current;
      wakeLockRef.current = null;
      if (lock && !lock.released) void lock.release();
    };
  }, [running]);

  const playPayload = useCallback((payload: 'tone' | 'chime' | 'siren') => {
    try {
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = sirenAudioRef.current?.state === 'closed'
        ? new AudioContextClass()
        : sirenAudioRef.current ?? new AudioContextClass();
      sirenAudioRef.current = ctx;
      void ctx.resume().then(() => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const duration = payload === 'siren' ? 1.8 : payload === 'chime' ? .72 : .42;
        osc.type = payload === 'chime' ? 'triangle' : 'sine';
        if (payload === 'tone') {
          osc.frequency.setValueAtTime(880, ctx.currentTime);
        } else if (payload === 'chime') {
          osc.frequency.setValueAtTime(660, ctx.currentTime);
          osc.frequency.setValueAtTime(990, ctx.currentTime + .18);
        } else {
          for (let step = 0; step < 6; step++) osc.frequency.setValueAtTime(step % 2 ? 520 : 760, ctx.currentTime + step * .3);
        }
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.13, ctx.currentTime + 0.025);
        gain.gain.setValueAtTime(0.13, ctx.currentTime + duration - .1);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration + .02);
        osc.onended = () => { osc.disconnect(); gain.disconnect(); };
      }).catch(() => { /* Browser audio can be blocked independently. */ });
    } catch { /* Sound is optional; the visual alert remains available. */ }
  }, []);

  const showAlert = useCallback((text: string) => {
    setAlertText(text);
    window.clearTimeout(alertTimerRef.current);
    alertTimerRef.current = window.setTimeout(() => setAlertText(''), 5200);
    if (audioTripwire) playPayload(audioPayload);
  }, [audioPayload, audioTripwire, playPayload]);

  const saveRecording = useCallback(async (blob: Blob) => {
    if (!blob.size) return;
    try {
      const clip: Clip = { id: Date.now(), createdAt: Date.now(), blob, type: blob.type || 'video/webm' };
      await saveClip(clip);
      await refreshClips();
      setStorageError('');
    } catch (e) {
      setStorageError(e instanceof Error ? `Recording couldn't be saved: ${e.message}` : 'Recording could not be saved. Check available device storage.');
    }
  }, [refreshClips]);

  const beginRecording = useCallback(() => {
    const current = streamRef.current;
    if (!current || recordingRef.current || typeof MediaRecorder === 'undefined') return;
    const supported = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4;codecs=h264,aac', 'video/mp4']
      .find(type => MediaRecorder.isTypeSupported(type));
    if (!supported) { setError('This browser does not support a compatible local video recording format.'); return; }
    try {
      const recorder = new MediaRecorder(current, { mimeType: supported });
      recordChunksRef.current = [];
      recordingRef.current = true;
      setRecording(true);
      recorderRef.current = recorder;
      recorder.ondataavailable = event => { if (event.data.size) recordChunksRef.current.push(event.data); };
      recorder.onerror = () => { setError('The browser could not record this event.'); recordingRef.current = false; setRecording(false); };
      recorder.onstop = () => {
        const blob = new Blob(recordChunksRef.current, { type: supported });
        recordChunksRef.current = [];
        recordingRef.current = false;
        setRecording(false);
        void saveRecording(blob);
      };
      recorder.start(500);
      window.setTimeout(() => {
        if (recorder.state !== 'inactive') recorder.stop();
      }, 10_000);
    } catch (e) {
      recordingRef.current = false;
      setRecording(false);
      setError(e instanceof Error ? `Recording unavailable: ${e.message}` : 'Could not start local recording.');
    }
  }, [saveRecording]);

  const stopCamera = useCallback(() => {
    cancelAnimationFrame(frameRef.current);
    frameRef.current = 0;
    const current = streamRef.current;
    current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    setStream(null);
    setRunning(false);
    setDim(false);
    lastPixelsRef.current = null;
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try { recorder.stop(); } catch { /* Already stopped. */ }
    }
  }, []);

  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      setDevices(all.filter(device => device.kind === 'videoinput'));
    } catch { setDevices([]); }
  }, []);

  const startCamera = useCallback(async () => {
    setError('');
    setStarting(true);
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access requires a secure context (HTTPS or localhost) and a browser that supports camera capture.');
      try {
        const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AudioContextClass) {
          const ctx = sirenAudioRef.current?.state === 'closed' ? new AudioContextClass() : sirenAudioRef.current ?? new AudioContextClass();
          sirenAudioRef.current = ctx;
          void ctx.resume().catch(() => { /* Audio is optional; visual alerts remain available. */ });
        }
      } catch { /* Audio support is optional. */ }
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: deviceId ? { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { facingMode: { ideal: cameraFacing }, width: { ideal: 1280 }, height: { ideal: 720 } },
      };
      const media = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = media;
      setStream(media);
      setRunning(true);
      const activeDeviceId = media.getVideoTracks()[0]?.getSettings().deviceId;
      if (activeDeviceId) setDeviceId(activeDeviceId);
      media.getVideoTracks()[0]?.addEventListener('ended', () => {
        stopCamera();
        setError('Camera capture ended. Your browser or device may have paused the camera.');
      }, { once: true });
      await refreshDevices();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Camera could not start. Check browser permission and try again.');
      stopCamera();
    } finally { setStarting(false); }
  }, [cameraFacing, deviceId, refreshDevices, stopCamera]);

  useEffect(() => {
    if (!running || !motionEnabled || !stream) {
      cancelAnimationFrame(frameRef.current);
      frameRef.current = 0;
      lastPixelsRef.current = null;
      return;
    }
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return;
    canvas.width = 64;
    canvas.height = 36;
    let lastSample = 0;
    let lastTrigger = 0;
    const sample = (time: number) => {
      frameRef.current = requestAnimationFrame(sample);
      if (time - lastSample < 180 || video.readyState < 2 || video.videoWidth === 0) return;
      lastSample = time;
      try {
        context.drawImage(video, 0, 0, 64, 36);
        const current = context.getImageData(0, 0, 64, 36).data;
        const previous = lastPixelsRef.current;
        lastPixelsRef.current = new Uint8ClampedArray(current);
        if (!previous) return;
        let changed = 0;
        let totalDiff = 0;
        for (let i = 0; i < current.length; i += 4) {
          const lum = (current[i] * .299 + current[i + 1] * .587 + current[i + 2] * .114);
          const oldLum = (previous[i] * .299 + previous[i + 1] * .587 + previous[i + 2] * .114);
          const diff = Math.abs(lum - oldLum);
          if (diff > 26) { changed++; totalDiff += diff; }
        }
        // Reject tiny flicker/noise; sensitivity adjusts the percentage of frame that must change.
        const changedRatio = changed / (64 * 36);
        const threshold = .105 - sensitivity * .00088;
        if (changedRatio > threshold && totalDiff / Math.max(changed, 1) > 34 && time - lastTrigger > 12_000) {
          lastTrigger = time;
          showAlert('Movement detected');
          beginRecording();
        }
      } catch {
        setError('Motion sampling is unavailable for this camera stream. Try another browser or camera.');
      }
    };
    frameRef.current = requestAnimationFrame(sample);
    return () => cancelAnimationFrame(frameRef.current);
  }, [beginRecording, motionEnabled, running, sensitivity, showAlert, stream]);

  useEffect(() => () => {
    cancelAnimationFrame(frameRef.current);
    streamRef.current?.getTracks().forEach(track => track.stop());
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') { try { recorder.stop(); } catch { /* unmount */ } }
    if (sirenAudioRef.current && sirenAudioRef.current.state !== 'closed') void sirenAudioRef.current.close();
    window.clearTimeout(alertTimerRef.current);
  }, []);

  const playSiren = useCallback(() => {
    const next = !sirenOn;
    setSirenOn(next);
    if (next) {
      setAlertText('Siren simulation active');
      window.clearTimeout(alertTimerRef.current);
      alertTimerRef.current = window.setTimeout(() => { setSirenOn(false); setAlertText(''); }, 6500);
      playPayload('siren');
    } else {
      window.clearTimeout(alertTimerRef.current);
      setAlertText('');
    }
  }, [playPayload, sirenOn]);

  const deleteClip = async (id: number) => {
    try {
      await removeClip(id);
      setClips(items => items.filter(item => item.id !== id));
      if (activeClip === id) setActiveClip(null);
    } catch (e) { setStorageError(e instanceof Error ? e.message : 'Could not delete clip.'); }
  };

  const downloadClip = (clip: Clip) => {
    const url = URL.createObjectURL(clip.blob);
    const link = document.createElement('a');
    link.href = url;
    const extension = clip.type.includes('mp4') ? 'mp4' : 'webm';
    link.download = `nightshift-sentry-${new Date(clip.createdAt).toISOString().replace(/[:.]/g, '-')}.${extension}`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1200);
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const result = await installPrompt.userChoice;
    if (result.outcome === 'accepted') setInstalled(true);
    setInstallPrompt(null);
  };

  return (
    <main className="app-shell">
      <header className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-5 md:px-9">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center border border-[#ccff00]/40 bg-[#171a10] text-[#ccff00] square-control"><Camera size={21} strokeWidth={1.8} /></div>
          <div><div className="graffiti-type text-[25px] font-extrabold tracking-[.03em]">NIGHTSHIFT SENTRY</div><div className="graffiti-type text-[13px] uppercase tracking-[.08em] text-[#74837a]">HYPER-VIGILANT DEFENSE NETWORK</div></div>
        </div>
        <div className="flex items-center gap-2">
          {installPrompt && <button onClick={installApp} className="hidden items-center gap-2 rounded-xl border border-[#d8d5ca] bg-[#fbfaf5] px-3 py-2 text-xs font-semibold text-[#35554b] hover:bg-white sm:flex" data-testid="button-install"><Download size={15} /> Install app</button>}
          {installed && <span className="hidden items-center gap-1 text-xs text-[#486d5f] sm:flex"><Check size={15} /> Installed</span>}
          <span className="offline-grid-badge graffiti-badge flex items-center gap-2 rounded-sm border border-[#ccff00]/30 bg-[#202416] px-3 py-2 text-[10px] font-bold tracking-[.08em] text-[#ccff00]"><LockKeyhole size={13} /> OFFLINE GRID / ZERO CLOUD FED SNOOPING</span>
        </div>
      </header>

      <section className="mx-auto max-w-[1440px] px-5 pb-10 md:px-9">
        <div className="mb-7 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div className="entrance">
            <p className="mono mb-2 text-[11px] uppercase tracking-[.19em] text-[#ccff00]">Field console / local device</p>
            <h1 className="graffiti-type text-3xl font-extrabold tracking-[-.025em] text-[#1f3731] md:text-[42px]">Don't blink. Don’t sleep.</h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-[#a2a2a7]">Safety. Security. Suspicious headlights. Motion events, stored locally. This camera detects pixel changes only; it does not identify or classify people.</p>
          </div>
          <div className="flex rounded-2xl border border-[#ddd9ce] bg-[#eae7dd] p-1.5" role="tablist" aria-label="Workspace mode">
            <button onClick={() => setMode('camera')} role="tab" aria-selected={mode === 'camera'} className={`flex items-center gap-2 rounded-sm px-4 py-2.5 text-xs font-bold uppercase tracking-[.1em] transition ${mode === 'camera' ? 'bg-[#fbfaf5] text-[#25483e] shadow-sm' : 'text-[#758078] hover:text-[#25483e]'}`} data-testid="tab-camera"><Camera size={16} /> Local camera</button>
            <button onClick={() => { if (running) stopCamera(); setMode('viewer'); }} role="tab" aria-selected={mode === 'viewer'} className={`flex items-center gap-2 rounded-sm px-4 py-2.5 text-xs font-bold uppercase tracking-[.1em] transition ${mode === 'viewer' ? 'bg-[#fbfaf5] text-[#25483e] shadow-sm' : 'text-[#758078] hover:text-[#25483e]'}`} data-testid="tab-viewer"><Eye size={16} /> Remote viewer</button>
          </div>
        </div>

        {(alertText || error || storageError) && <div className={`mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border px-4 py-3 ${alertText ? 'border-[#e7c7b6] bg-[#fff0e8] text-[#8b4935]' : 'border-[#e6c6b7] bg-[#fff1eb] text-[#824632]'}`} role="status" aria-live="assertive">
          <div className="flex items-start gap-2.5">{alertText ? <Bell size={18} className="mt-0.5 shrink-0" /> : <AlertTriangle size={18} className="mt-0.5 shrink-0" />}<span className="text-sm font-semibold">{alertText || error || storageError}</span></div>
          {alertText && <button onClick={() => { setAlertText(''); setSirenOn(false); }} aria-label="Dismiss alert" className="rounded-lg p-1 hover:bg-[#f4ded2]"><X size={17} /></button>}
        </div>}

        <div className="dashboard-grid">
          <section className="min-w-0 overflow-hidden rounded-[26px] border border-[#ddd9ce] bg-[#fbfaf5] shadow-[0_8px_28px_rgba(32,54,46,.045)]">
            <div className="flex items-center justify-between gap-3 px-5 py-4 md:px-6">
              <div className="flex items-center gap-2.5"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#e8eee6] text-[#426857]"><Video size={18} /></div><div><h2 className="graffiti-type text-base font-bold tracking-[-.02em]">{mode === 'camera' ? 'Camera preview' : 'Live view'}</h2><p className="text-[11px] text-[#829087]">{mode === 'camera' ? 'This device camera' : 'Remote camera connection'}</p></div></div>
              {mode === 'camera' && <span className={`graffiti-badge flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${running ? 'bg-[#eaf3e8] text-[#477353]' : 'bg-[#eeece5] text-[#83887f]'}`}><span className={`h-1.5 w-1.5 ${running ? 'status-live bg-[#ccff00]' : 'bg-[#77777d]'}`} />{running ? 'Feed live' : 'Feed parked'}</span>}
              {mode === 'viewer' && <span className="graffiti-badge rounded-full bg-[#f3eadc] px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] text-[#986d34]">Not paired</span>}
            </div>
            <div className={`camera-stage ${alertText ? 'alert-flash' : ''}`}>
              {mode === 'camera' && stream ? <video ref={videoRef} autoPlay playsInline muted aria-label="Active camera preview" data-testid="camera-preview" /> : null}
              <div className="camera-grid" />
              <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
              {mode === 'camera' && !stream && <div className="absolute inset-0 z-[1] flex flex-col items-center justify-center px-6 text-center text-[#f6f0e2]">
                <div className="standby-eyes mb-4" role="img" aria-label="Camera on standby">👀</div>
                <p className="graffiti-type text-xl font-bold uppercase tracking-[.03em]">Camera bay idle</p>
                <p className="mt-2 max-w-sm text-sm leading-6 text-[#d0d5ca]">Arm local watch to preview this device. No upload, no remote feed, no mysterious dashboard cloud.</p>
                <span className="mono mt-5 border border-white/15 px-3 py-1.5 text-[10px] uppercase tracking-[.15em] text-[#c3cec4]">Awaiting operator</span>
              </div>}
              {mode === 'viewer' && <div className="absolute inset-0 z-[1] flex flex-col items-center justify-center px-6 text-center text-[#f6f0e2]">
                <div className="mb-4 grid h-[68px] w-[68px] place-items-center rounded-[22px] border border-white/15 bg-white/[.08]"><Radio size={27} strokeWidth={1.5} /></div>
                <p className="graffiti-type text-xl font-bold uppercase tracking-[.03em]">Viewer not paired</p>
                <p className="mt-2 max-w-md text-sm leading-6 text-[#d0d5ca]">This screen is not an active live feed. Remote pairing is not implemented; local recordings remain available on the camera device.</p>
                <span className="mono mt-5 border border-white/15 px-3 py-1.5 text-[10px] uppercase tracking-[.13em] text-[#c3cec4]">NOT PAIRED · NOT ACTIVE</span>
              </div>}
              {mode === 'camera' && running && <div className="absolute bottom-4 left-4 z-[2] flex items-center gap-2 rounded-lg bg-[#172823]/75 px-3 py-2 text-xs text-white backdrop-blur-sm"><span className="status-live h-2 w-2 rounded-full bg-[#80c77c]" /> Camera active on this device</div>}
            </div>
            {mode === 'camera' && running && <div className="console-feed px-5 py-3 md:px-6" aria-label="Local system terminal" aria-live="polite">
              <div className="mb-1 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[.18em] text-[#85858a]"><Terminal size={13} className="text-[#ccff00]" /> Local process log <span className="ml-auto">NO NETWORK</span></div>
              <div className="console-row font-mono text-[10px] text-[#d0d0c7]"><span className="console-dot" />CAMERA FEED <span className="text-[#ccff00]">ACTIVE · DEVICE ONLY</span></div>
              <div className="console-row font-mono text-[10px] text-[#a7a7a9]"><span className="console-dot" />PIXEL SAMPLER <span>64×36 / 180ms · ΔL &gt; 26 · threshold {((.105 - sensitivity * .00088) * 100).toFixed(1)}%</span></div>
              <div className="console-row font-mono text-[10px] text-[#a7a7a9]"><span className={`h-[6px] w-[6px] flex-none ${recording ? 'bg-[#ff5500]' : 'bg-[#77777d]'}`} />CLIP RECORDER <span className={recording ? 'text-[#ff6a32]' : ''}>{recording ? 'RECORDING · 10 SEC LOCAL CLIP' : 'ARMED · WAITING FOR PIXEL CHANGE'}</span></div>
            </div>}
            {mode === 'camera' ? <div className="space-y-5 p-5 md:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex gap-2">
                  {!running ? <button onClick={startCamera} disabled={starting} aria-label="Start local camera monitoring" title="Start local camera monitoring" className={`heart-start-button grid h-14 w-14 place-items-center rounded-full bg-[#245448] text-[#111] shadow-[0_0_22px_rgba(204,255,0,.2)] transition hover:bg-[#d9ff32] disabled:opacity-65 ${starting ? '' : 'heart-prime'}`} data-testid="button-start-camera">{starting ? <LoaderCircle size={22} className="animate-spin" /> : <Heart size={25} fill="currentColor" strokeWidth={2.5} />}</button> : <button onClick={stopCamera} className="flex items-center gap-2 rounded-sm bg-[#f7e7e0] px-4 py-3 text-xs font-bold uppercase tracking-[.12em] text-[#914d3c] hover:bg-[#f2d9ce]" data-testid="button-stop-camera"><StopCircle size={17} /> Disarm watch</button>}
                </div>
                <label className="flex items-center gap-2 text-xs font-medium text-[#66766d]"><span>Camera</span><select value={deviceId || cameraFacing} onChange={e => {
                  const value = e.target.value;
                  if (value === 'user' || value === 'environment') { setCameraFacing(value); setDeviceId(''); }
                  else { setDeviceId(value); }
                  if (running) stopCamera();
                }} className="max-w-[190px] rounded-lg border border-[#dedace] bg-[#f7f5ee] px-2.5 py-2 text-xs text-[#345348] outline-none focus:ring-2 focus:ring-[#9db7a4]" aria-label="Choose camera" data-testid="select-camera">
                  <option value="environment">Back camera</option>
                  <option value="user">Front camera</option>
                  {devices.map((device, index) => <option key={device.deviceId} value={device.deviceId}>{device.label || `Camera ${index + 1}`}</option>)}
                </select></label>
              </div>
              {devices.length === 0 && <p className="-mt-3 text-[11px] text-[#8b958c]">Front / back choice is used until camera permission reveals available devices.</p>}
              <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-sm border border-[#e3dfd3] bg-[#f7f5ee] p-4">
                  <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2 text-sm font-semibold text-[#334b42]"><ShieldCheck size={17} /> Pixel watch</div><button role="switch" aria-checked={motionEnabled} onClick={() => setMotionEnabled(v => !v)} className={`relative h-6 w-11 rounded-full transition ${motionEnabled ? 'bg-[#487960]' : 'bg-[#c4c8bf]'}`} aria-label="Toggle pixel-change detection" data-testid="toggle-motion"><span className={`absolute top-[3px] h-[18px] w-[18px] rounded-full bg-white shadow-sm transition-transform ${motionEnabled ? 'translate-x-[21px]' : 'translate-x-[3px]'}`} /></button></div>
                  <label className="block text-xs text-[#748078]">Pixel-change sensitivity <span className="float-right font-semibold text-[#486558]">{sensitivity}%</span><input type="range" min="10" max="90" value={sensitivity} onChange={e => setSensitivity(Number(e.target.value))} className="mt-3 w-full accent-[#46755f]" aria-label="Pixel-change sensitivity" data-testid="slider-sensitivity" /></label>
                  <p className="mt-2 text-[10px] leading-4 text-[#8a948b]">Higher values catch smaller pixel shifts. Lower values filter lighting flicker and passing housecats.</p>
                </div>
                <div className="rounded-sm border border-[#e3dfd3] bg-[#f7f5ee] p-4">
                  <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2 text-sm font-semibold text-[#334b42]"><MonitorOff size={17} /> Ghost mode / screen blackout</div><button role="switch" aria-checked={dim} disabled={!running} onClick={() => setDim(v => !v)} className={`relative h-6 w-11 rounded-full transition disabled:opacity-40 ${dim ? 'bg-[#487960]' : 'bg-[#c4c8bf]'}`} aria-label="Toggle dim screen" data-testid="toggle-dim"><span className={`absolute top-[3px] h-[18px] w-[18px] rounded-full bg-white shadow-sm transition-transform ${dim ? 'translate-x-[21px]' : 'translate-x-[3px]'}`} /></button></div>
                  <p className="text-xs leading-5 text-[#748078]">Blacks out this display while watch is armed. Tap anywhere to bring controls back.</p>
                </div>
              </div>
              <section className="rounded-sm border border-[#38382f] bg-[#171713] p-4" aria-labelledby="audio-tripwire-title">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div><div className="flex items-center gap-2"><Volume2 size={16} className="text-[#ccff00]" /><h3 id="audio-tripwire-title" className="graffiti-type text-xs font-bold tracking-[.08em] text-[#ccff00]">AUTOMATED AUDIO TRIPWIRE MATRIX</h3><span className="rounded-sm border border-[#ff5500]/40 px-1.5 py-0.5 font-mono text-[9px] text-[#ff7b52]">OPT-IN</span></div><p className="mt-1 text-[11px] text-[#9b9b9d]">Local synthesized sound on pixel change. Starts off.</p></div>
                  <button role="switch" aria-checked={audioTripwire} onClick={() => setAudioTripwire(value => !value)} className={`relative h-6 w-11 transition ${audioTripwire ? 'bg-[#ccff00]' : 'bg-[#49494d]'}`} aria-label="Enable audio tripwire" data-testid="toggle-audio-tripwire"><span className={`absolute top-[3px] h-[18px] w-[18px] bg-[#f0f0e9] shadow-sm transition-transform ${audioTripwire ? 'translate-x-[21px]' : 'translate-x-[3px]'}`} /></button>
                </div>
                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <label className="min-w-0 flex-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#88888d]">Payload<select value={audioPayload} onChange={event => setAudioPayload(event.target.value as typeof audioPayload)} className="mt-1 block w-full rounded-sm border px-3 py-2 text-xs normal-case tracking-normal" aria-label="Select synthesized audio payload" data-testid="select-audio-payload"><option value="tone">Short alert tone</option><option value="chime">Warning chime</option><option value="siren">Siren simulation</option></select></label>
                  <button onClick={() => playPayload(audioPayload)} className="mt-auto flex min-h-[38px] items-center justify-center gap-2 border border-[#ccff00]/40 px-3 py-2 text-xs font-bold uppercase tracking-[.1em] text-[#ccff00] transition hover:bg-[#ccff00] hover:text-[#111]" data-testid="button-preview-audio"><Play size={14} /> Preview</button>
                </div>
                <p className="mt-2 text-[10px] leading-4 text-[#77777c]">No physical flash or screen strobe. The visual motion alert remains available independently.</p>
              </section>
            </div> : <div className="flex flex-wrap items-center justify-between gap-3 p-5 md:p-6">
              <div className="flex items-start gap-3"><div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#f2eadb] text-[#99703a]"><Info size={17} /></div><div><p className="text-sm font-semibold text-[#364b41]">Local clips only</p><p className="mt-1 max-w-lg text-xs leading-5 text-[#79847a]">Recordings do not sync across devices. A future pairing feature is not currently connected.</p></div></div>
                <button onClick={playSiren} className={`flex items-center gap-2 rounded-sm px-4 py-3 text-xs font-bold uppercase tracking-[.1em] transition ${sirenOn ? 'bg-[#a84f3d] text-white' : 'border border-[#e1cfc0] bg-[#fbf2e8] text-[#8d5939] hover:bg-[#f7eadb]'}`} data-testid="button-siren"><Siren size={17} />{sirenOn ? 'Stop simulation' : 'Test siren simulation'}</button>
            </div>}
          </section>

          <aside className="flex min-w-0 flex-col gap-5">
            <section className="rounded-[26px] border border-[#ddd9ce] bg-[#fbfaf5] p-5 shadow-[0_8px_28px_rgba(32,54,46,.035)] md:p-6">
              <div className="mb-4 flex items-center justify-between">
                <div><p className="mono text-[10px] uppercase tracking-[.16em] text-[#879188]">LOCAL CLIP CACHE</p><h2 className="graffiti-type mt-1 text-lg font-bold uppercase tracking-[.03em]">INCIDENT LOGS / EVIDENCE BIN</h2></div>
                <span className="mono rounded-full bg-[#e9eee6] px-2.5 py-1 text-xs text-[#4d6e5b]">{clips.length.toString().padStart(2, '0')}</span>
              </div>
              {storageError && <div className="mb-4 rounded-xl border border-[#e6c6b7] bg-[#fff1eb] px-3 py-2 text-xs leading-5 text-[#824632]" role="alert">{storageError}</div>}
              {clips.length === 0 ? <div className="rounded-2xl border border-dashed border-[#d9d8cc] bg-[#f8f6ef] px-5 py-8 text-center">
                <div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-[#e8eee6] text-[#65816d]"><Film size={20} /></div>
                  <p className="graffiti-type text-sm font-semibold text-[#42584c]">No motion events logged yet.</p>
                  <p className="mx-auto mt-1.5 max-w-[245px] text-xs leading-5 text-[#a2a2a7]">When pixel changes cross the threshold, a 10-second playback reel is saved locally in this browser.</p>
                <button onClick={refreshClips} className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-[#567463] hover:text-[#284c3b]" data-testid="button-refresh-clips"><RefreshCw size={13} /> Rescan local cache</button>
              </div> : <div className="space-y-3">
                {clips.map(clip => {
                  const url = clipUrls.get(clip.id) || '';
                  return <article key={clip.id} className="overflow-hidden rounded-2xl border border-[#e3dfd3] bg-[#f8f6ef]" data-testid={`recording-${clip.id}`}>
                    {activeClip === clip.id ? <video controls autoPlay src={url} className="aspect-video w-full bg-[#1c302b]" onEnded={() => setActiveClip(null)} aria-label={`Recording from ${formatTime(clip.createdAt)}`} /> : <div className="clip-thumb relative flex aspect-[2.25/1] items-center justify-center"><span className="absolute left-3 top-3 rounded-md bg-[#13241e]/70 px-2 py-1 text-[9px] font-bold uppercase tracking-[.13em] text-white">Motion event</span><button onClick={() => setActiveClip(clip.id)} className="grid h-10 w-10 place-items-center rounded-full border border-white/40 bg-[#f8f3e7]/90 text-[#234b3e] shadow-lg hover:scale-105" aria-label={`Play recording from ${formatTime(clip.createdAt)}`} data-testid={`button-play-${clip.id}`}><Play size={17} fill="currentColor" /></button></div>}
                    <div className="flex items-center justify-between gap-2 px-3.5 py-3">
                      <div className="min-w-0"><p className="truncate text-xs font-semibold text-[#40564a]">{formatTime(clip.createdAt)}</p><p className="mono mt-1 text-[9px] uppercase tracking-[.12em] text-[#929990]">10 sec · {clip.type.split(';')[0]}</p></div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => downloadClip(clip)} className="rounded-lg p-2 text-[#65806f] hover:bg-[#e8eee6] hover:text-[#315742]" aria-label="Download recording" title="Download" data-testid={`button-download-${clip.id}`}><Download size={16} /></button>
                        <button onClick={() => void deleteClip(clip.id)} className="rounded-lg p-2 text-[#9a8177] hover:bg-[#f2e4dc] hover:text-[#9b4b38]" aria-label="Delete recording" title="Delete" data-testid={`button-delete-${clip.id}`}><Trash2 size={15} /></button>
                      </div>
                    </div>
                  </article>;
                })}
              </div>}
              <div className="mt-4 flex items-center gap-2 border-t border-[#e7e3d9] pt-4 text-[11px] leading-4 text-[#879188]"><HardDrive size={14} className="shrink-0" />Stored in this browser only. Clearing site data removes recordings.</div>
            </section>
            <section className="rounded-[26px] bg-[#e7ece4] p-5 md:p-6">
              <div className="mb-3 flex items-center gap-2 text-[#466555]"><CircleHelp size={17} /><h2 className="graffiti-type text-sm font-bold">A note about camera use</h2></div>
              <p className="text-xs leading-[1.7] text-[#68796f]">Camera capture needs a secure context (HTTPS or localhost) and your permission. Background execution varies by browser and device: mobile browsers may pause capture, sampling, or recording when backgrounded. Keep this page visible for best results.</p>
              <div className="mt-4 flex items-center gap-2 border-t border-[#d5ded3] pt-3 text-[10px] font-medium text-[#718477]"><Smartphone size={13} /> No cloud. No account. No server storage.</div>
            </section>
            {installPrompt && <button onClick={installApp} className="flex items-center justify-center gap-2 rounded-sm border border-[#ddd9ce] bg-[#fbfaf5] px-4 py-3 text-sm font-semibold text-[#3e6150] sm:hidden"><Download size={16} /> Install Sentry</button>}
            {installed && <div className="flex items-center gap-2 px-2 text-xs text-[#527361]"><Check size={15} /> Sentry is installed on this device</div>}
          </aside>
        </div>
        <footer className="premium-banner mt-7 flex flex-col gap-4 border border-[#34342d] p-5 md:flex-row md:items-center md:justify-between md:p-6">
          <div className="max-w-2xl"><p className="mono text-[10px] font-bold uppercase tracking-[.18em] text-[#ff6a32]">Current status: Junk Drawer Captain · Free / Local Only</p><h2 className="brand-display mt-1 text-lg font-bold uppercase tracking-[.04em]">Block Captain tier — concept only.</h2><p className="mt-1 text-xs leading-5 text-[#a2a2a7]">Paid upgrades, billing, and neighborhood alerts are not implemented. Nothing is locked behind payment; this console runs locally as shown.</p></div>
          <button onClick={() => { setAlertText('Demo only: paid upgrades, billing, and neighborhood alerts are not implemented.'); window.clearTimeout(alertTimerRef.current); alertTimerRef.current = window.setTimeout(() => setAlertText(''), 5200); }} className="square-control flex shrink-0 items-center justify-center gap-2 border border-[#ff5500]/45 px-4 py-3 text-xs font-bold uppercase tracking-[.12em] text-[#ff7950] transition hover:bg-[#ff5500]/10" aria-label="Learn about the Block Captain demo concept">Block Captain details <Info size={14} /></button>
        </footer>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 font-mono text-[9px] uppercase tracking-[.13em] text-[#77777d]"><span>NIGHTSHIFT SENTRY · LOCAL BROWSER TOOL</span><span>PIXEL CHANGES ONLY · NO CLASSIFICATION</span></div>
      </section>
      {mode === 'camera' && dim && running && <button onClick={() => setDim(false)} className="dim-layer fixed inset-0 z-50 flex flex-col items-center justify-center gap-3 text-[#d7dfd6]" aria-label="Reveal camera controls" data-testid="button-reveal-controls"><Eye size={20} /><span className="text-xs">Tap anywhere to reveal controls</span></button>}
    </main>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default App;
